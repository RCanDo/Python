from distutils.core import setup

setup(name='Towel',
      version='0.1dev',
      packages=['towelstuff',],
      licence='Creative Commons Attribution-Noncommercial-Share Alike license',
      long_description=open('README.txt').read(),
      )