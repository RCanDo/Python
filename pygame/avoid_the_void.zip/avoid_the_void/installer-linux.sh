#! /bin/bash
python3 -m pip install -U pygame --user
