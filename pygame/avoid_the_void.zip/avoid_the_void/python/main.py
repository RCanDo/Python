import pygame

import game

pygame.init()
screen, running = pygame.display.set_mode((700, 700)), True
pygame.display.set_caption("Avoid the Void")

this = game.Game()

while running:
    screen.fill((144,198,238))

    for event in pygame.event.get():
        this.handle_events(event)
        if event.type == pygame.QUIT:
            running = False
    
    this.tick(screen)
    
    pygame.display.update()