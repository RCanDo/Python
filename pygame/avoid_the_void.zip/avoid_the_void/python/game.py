import pygame
from random import choice

import field
import player

class Game:
    fcount = 0
    over = False
    def __init__(self):
        self.fields = []
        for x in range(14):
            for y in range(14):
                self.fields.append(field.Field())
                self.fields[-1].x = x
                self.fields[-1].y = y
        
        self.clock = pygame.time.Clock()
        self.player = player.Player()
    def start_field(self):
        c = choice(self.fields)
        if c.running == False: c.running = True
        else: self.start_field()
    def tick(self, surface):
        self.clock.tick(50)

        if self.fcount > 19:
           self.start_field()
           self.fcount = 0
        
        if not self.over:
            step = 0
            for f in self.fields:
                f.show(surface)
                f.tick(self.fields, step)
                step += 1
        
        self.player.show(surface)
        if self.player.tick(surface):
            self.over = True
        
        self.fcount += 1
    
    def handle_events(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w and self.player.y > 0:
                self.player.y -= 1
            if event.key == pygame.K_s and self.player.y < 13:
                self.player.y += 1
            if event.key == pygame.K_a and self.player.x > 0:
                self.player.x -= 1
            if event.key == pygame.K_d and self.player.x < 13:
                self.player.x += 1
            if event.key == pygame.K_SPACE and self.over:
                self.over = False
                self.__init__()