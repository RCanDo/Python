import pygame
from random import randint

# 0,205,0
# 255,165,0
# 205,133,0
# 205,38,38

class Field:
    health = 100
    running = False
    x, y = 0, 0
    def __init__(self):
        self.x, self.y = 0, 0
    
    def show(self, surface):
        pygame.draw.rect(surface, (0, 205, 0), [self.x*50, self.y*50, 50, 50])
        if self.health < 75:
            pygame.draw.rect(surface, (255, 165, 0), [self.x*50, self.y*50, 50, 50])
        if self.health < 50:
            pygame.draw.rect(surface, (205, 133, 0), [self.x*50, self.y*50, 50, 50])
        if self.health < 25:
            pygame.draw.rect(surface, (205, 38, 38), [self.x*50, self.y*50, 50, 50])
    
    def tick(self, all_fields, id):
        if self.running:
            self.health -= randint(4, 8)/50
        if self.health < 1:
            all_fields.pop(id)
    