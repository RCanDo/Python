import pygame
from random import randint

import Global

class Player:
    x,y = 0, 0
    def __init__(self):
        self.x = randint(0, 10)
        self.y = randint(0, 10)
        self.img = pygame.transform.scale(pygame.image.load(Global.path+"textures/player.png"), (48, 48))
    def show(self, surface):
        surface.blit(self.img, [(self.x*50)+1, (self.y*50)+1])
    def tick(self, surface):
        #print(surface.get_at([(self.x*50)+1, (self.y*50)+1])[:3])
        if surface.get_at([(self.x*50)+1, (self.y*50)+1])[:3] == (144,198,238):
            return True
        else:
            return False