#! /bin/bash
python3 python/main.py
